import React, { useState } from 'react'
import './input.css'
// import Input1 from './Input1'
// import { FaTimes } from "react-icons/fa";
function Input() {
    const[item,setItem]=useState("")
    const[items,setItems]=useState([])
    const delet=(e)=>{
      const value=items[e.target.value]
      setItems((ty)=>{
        let b=ty.filter(ele=> ele!==value)
        return b;
      })
    }
    const update=(f)=>{
      
    }
  return (
    <>
     <center>
         <div className='div1'>
             <h1 className='h1'>All Notes <i class="fa-thin fa-greater-than"></i></h1>  
             <input type="text" value={item} onChange={(e)=>{ setItem(e.target.value)}}/>
             <button onClick={()=>{ setItems((ty)=>{
             return[...ty,item]
             })
            //  setItem("")
             }}> 
             ADD </button>
             <ol>
                 {items.map((elem,index)=>{
                     return( 
                          <div className='div2'>
                          <li key={index}>{elem}<button type='button' className='button1' onClick={delet} value={index}><i class="fa-sharp fa-solid fa-trash"></i></button><button onClick={update}><i class="fa-solid fa-pen"></i></button></li>
                          </div>
                        )
                  })} 
                {/* <Input1/> */}
             </ol>
         </div>
     </center>
     
    </> 
  )
}
export default Input