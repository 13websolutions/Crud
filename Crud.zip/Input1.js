import React from 'react'
const Input1 = (props) => {
  return (
    <li>{props.text}</li>
  )
}

export default Input1;